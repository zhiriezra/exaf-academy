<?php $__env->startSection('content'); ?>

<div class="min-h-svh">

    <section>

        <div class="md:mt-8 p-6 space-y-6">
            <h2 class="text-2xl md:text-3xl font-semibold text-ezra-green">About this Program</h2>

            <p class="">The Agribusiness Extension Program for Professionals (AEPP) is designed to empower stakeholders in the agribusiness sector to effectively reach and support last-mile farmers. The program equips agents working for these stakeholders with the knowledge and skills necessary to improve business delivery and service provision, ultimately leading to solutions that address the specific needs of these farmers.</p>

            <div class="flex flex-wrap md:flex-nowrap justify-around gap-4">
                <img src="<?php echo e(asset('images/fba.webp')); ?>" alt="" class="w-full md:w-1/2 md:h-72 object-cover object-center">

                <div class="w-full">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure'])->html();
} elseif ($_instance->childHasBeenRendered('abpg64q')) {
    $componentId = $_instance->getRenderedChildComponentId('abpg64q');
    $componentTag = $_instance->getRenderedChildComponentTagName('abpg64q');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('abpg64q');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure']);
    $html = $response->html();
    $_instance->logRenderedChild('abpg64q', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.'])->html();
} elseif ($_instance->childHasBeenRendered('2qui5Q1')) {
    $componentId = $_instance->getRenderedChildComponentId('2qui5Q1');
    $componentTag = $_instance->getRenderedChildComponentTagName('2qui5Q1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2qui5Q1');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.']);
    $html = $response->html();
    $_instance->logRenderedChild('2qui5Q1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.'])->html();
} elseif ($_instance->childHasBeenRendered('i29ej8u')) {
    $componentId = $_instance->getRenderedChildComponentId('i29ej8u');
    $componentTag = $_instance->getRenderedChildComponentTagName('i29ej8u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('i29ej8u');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.']);
    $html = $response->html();
    $_instance->logRenderedChild('i29ej8u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.'])->html();
} elseif ($_instance->childHasBeenRendered('FmHVcOp')) {
    $componentId = $_instance->getRenderedChildComponentId('FmHVcOp');
    $componentTag = $_instance->getRenderedChildComponentTagName('FmHVcOp');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('FmHVcOp');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.']);
    $html = $response->html();
    $_instance->logRenderedChild('FmHVcOp', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                </div>

            </div>

            <div class="flex justify-center">
                <a href="" class="bg-yellow-500 hover:bg-yellow-400 text-white px-6 py-1 shadow-xl hover:shadow-none transition-shadow rounded-lg">Start Learning Today</a>
            </div>
        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/pages/pathway.blade.php ENDPATH**/ ?>