<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Afrexa - Authentication</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>
    <div class="container mx-auto">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</html>
<?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/layouts/components/auth/master.blade.php ENDPATH**/ ?>