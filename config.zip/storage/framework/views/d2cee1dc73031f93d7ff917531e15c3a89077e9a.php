<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Afrexa - Home</title>
  <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="max-w-screen-2xl mx-auto text-ezra-dark">
    <nav class="mx-auto p-4 bg-white">
        <div class="mx-auto flex justify-between items-center">
            <a href="/" class="focus:outline-none focus-visible:ring-4 ring-neutral-900 rounded-sm ring-offset-4 ring-offset-white hover:opacity-75 transition-opacity">
                <img src="<?php echo e(asset('images/logo-compact.png')); ?>" width="200" class="w-14 md:w-16 lg:w-20" alt="logo">
            </a>

            <button id="menu" aria-expanded="false" aria-label="Open Menu" class="md:hidden focus:outline-none focus-visible:ring-4 ring-neutral-900 rounded-sm ring-offset-4 ring-offset-white hover:text-neutral-600 transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-8 h-8">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
                </svg>
            </button>

            <div role="menubar" class="hidden flex-col items-center gap-4 absolute right-0 left-0 top-20 bg-neutral-50 shadow-xl text-center p-6 text-lg md:flex md:flex-row md:static md:shadow-none md:justify-end md:w-full md:bg-white">
                <a href="" role="menuitem" class="focus:outline-none focus-visible:ring-4 ring-neutral-900 rounded-sm ring-offset-4 ring-offset-white hover:opacity-75 transition-opacity border-b-2 border-yellow-400">Home</a>
                <a href="" role="menuitem" class="focus:outline-none focus-visible:ring-4 ring-neutral-900 rounded-sm ring-offset-4 ring-offset-white hover:opacity-75 transition-opacity">Contact</a>
                <a href="" role="menuitem" class="focus:outline-none focus-visible:ring-4 ring-neutral-900 rounded-sm ring-offset-4 ring-offset-white hover:opacity-75 transition-opacity">About</a>
                <a href="" role="menuitem" class="focus:outline-none focus-visible:ring-4 ring-neutral-900 rounded-md ring-offset-4 ring-offset-white hover:opacity-75 transition-opacity">Login</a>
                <a href="" role="menuitem" class="focus:outline-none focus-visible:ring-4 ring-neutral-900 rounded-md ring-offset-4 ring-offset-white bg-yellow-500 text-white px-6 py-1 shadow-xl hover:shadow-none transition-shadow">Create Account</a>
            </div>

        </div>
    </nav>

    <header class="p-6 bg-ezra-green">
        <div class="container mx-auto md:flex justify-around gap-6 items-center text-white">
            <div class="flex justify-center">
                <img src="<?php echo e(asset('images/farmer-agent-phone-smiling-scaled.png')); ?>" class="w-60 md:w-72" alt="">
            </div>

            <div class="space-y-4">
                <h4 class="text-[40px] font-bold">Africa Agribusiness Extension Academy</h4>
                <p class="text-lg">Expertly crafted courses for all stakeholders across the Agro-allied value chain.</p>
                <button class="bg-white text-ezra-green py-1 px-6 focus-visible:ring-4 ring-neutral-900 ring-offset-4 ring-offset-white hover:text-ezra-green-dark transition-colors text-xl rounded-md shadow-lg hover:shadow-none">Start learning</button>
            </div>
        </div>
    </header>

    <main class="mt-8 grid gap-12 sm:gap-16 md:gap-18 lg:gap-20 overflow-hidden">

        <?php echo e($slot); ?>


        

    </main>

    <footer class="bg-ezra-green-dark text-white py-4">
        <div class="space-y-8 md:space-y-0 px-6 md:grid md:grid-cols-2 md:items-start">
            <div class="container mx-auto flex justify-center space-x-4 md:justify-start md:gap-4 md:colspan-1">
                <a href="">Contact</a>
                <a href="">Terms and Services</a>
                <a href="">Privacy Policy</a>
            </div>

            <div class="md:colspan-1 md:grid md:justify-end">
                <div class="text-center md:text-start">
                    <p>Nigeria: +234 7035621550</p>
                    <p>South Africa: +241 7035621552</p>
                    <p>hello@extensionafrica.com</p>
                </div>

                <div class="flex justify-center md:justify-start items-center">
                    <a href="" class="">
                        <img src="<?php echo e(asset('images/icons8-linkedin.svg')); ?>" alt="">
                    </a>

                    <a href="" class="">
                        <img src="<?php echo e(asset('images/icons8-twitter.svg')); ?>" alt="">
                    </a>

                    <a href="" class="">
                        <img src="<?php echo e(asset('images/icons8-facebook.svg')); ?>" alt="">
                    </a>
                </div>

            </div>
        </div>
        <div class="px-6 pt-8 text-center text-sm text-neutral-400">
            <?php echo e(date('Y')); ?> All Rights Reserved Extension Africa
        </div>
    </footer>
    <script src="<?php echo e(asset('main.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/layouts/master.blade.php ENDPATH**/ ?>