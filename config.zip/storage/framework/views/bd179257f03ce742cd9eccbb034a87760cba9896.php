<?php $__env->startSection('content'); ?>

<div class="min-h-svh">

    <section>

        <div class="md:mt-8 p-6 space-y-6">
            <h2 class="text-2xl md:text-3xl font-semibold text-ezra-green">About this Program</h2>

            <p class="">The Student Agribusiness Extension Program (SAEP) equips students with the knowledge and skills necessary to pursue careers in agribusiness. The program offers a comprehensive learning experience that combines classroom instruction, practical application through internships, and online learning opportunities.</p>

            <div class="flex flex-wrap md:flex-nowrap justify-around gap-4">
                <img src="<?php echo e(asset('images/fba.webp')); ?>" alt="" class="w-full md:w-1/2 md:h-72 object-cover object-center">

                <div class="w-full">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure'])->html();
} elseif ($_instance->childHasBeenRendered('wudGJhy')) {
    $componentId = $_instance->getRenderedChildComponentId('wudGJhy');
    $componentTag = $_instance->getRenderedChildComponentTagName('wudGJhy');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wudGJhy');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure']);
    $html = $response->html();
    $_instance->logRenderedChild('wudGJhy', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.'])->html();
} elseif ($_instance->childHasBeenRendered('KaDNsDZ')) {
    $componentId = $_instance->getRenderedChildComponentId('KaDNsDZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('KaDNsDZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KaDNsDZ');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.']);
    $html = $response->html();
    $_instance->logRenderedChild('KaDNsDZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.'])->html();
} elseif ($_instance->childHasBeenRendered('bj0CA2E')) {
    $componentId = $_instance->getRenderedChildComponentId('bj0CA2E');
    $componentTag = $_instance->getRenderedChildComponentTagName('bj0CA2E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('bj0CA2E');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.']);
    $html = $response->html();
    $_instance->logRenderedChild('bj0CA2E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.'])->html();
} elseif ($_instance->childHasBeenRendered('cX42s6v')) {
    $componentId = $_instance->getRenderedChildComponentId('cX42s6v');
    $componentTag = $_instance->getRenderedChildComponentTagName('cX42s6v');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cX42s6v');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.']);
    $html = $response->html();
    $_instance->logRenderedChild('cX42s6v', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                </div>

            </div>

            <div class="flex justify-center">
                <a href="<?php echo e(route('register')); ?>" class="bg-yellow-500 hover:bg-yellow-400 text-white px-6 py-1 shadow-xl hover:shadow-none transition-shadow rounded-lg">Start Learning Today</a>
            </div>
        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/pages/saep.blade.php ENDPATH**/ ?>