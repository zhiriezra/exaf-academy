<?php $__env->startSection('content'); ?>

<div class="min-h-svh">

    <section>

        <div class="md:mt-8 p-6 space-y-6">
            <h2 class="text-2xl md:text-3xl font-semibold text-ezra-green">About this Program</h2>

            <p class="">The Agribusiness Extension Program for Professionals (AEPP) is designed to empower stakeholders in the agribusiness sector to effectively reach and support last-mile farmers. The program equips agents working for these stakeholders with the knowledge and skills necessary to improve business delivery and service provision, ultimately leading to solutions that address the specific needs of these farmers.</p>

            <div class="flex flex-wrap md:flex-nowrap justify-around gap-4">
                <img src="<?php echo e(asset('images/aepp-resized.png')); ?>" alt="" class="w-full md:w-1/2 md:h-72 object-cover object-top">

                <div class="w-full">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure'])->html();
} elseif ($_instance->childHasBeenRendered('ShGUuYX')) {
    $componentId = $_instance->getRenderedChildComponentId('ShGUuYX');
    $componentTag = $_instance->getRenderedChildComponentTagName('ShGUuYX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ShGUuYX');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure']);
    $html = $response->html();
    $_instance->logRenderedChild('ShGUuYX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.'])->html();
} elseif ($_instance->childHasBeenRendered('F2g9fQk')) {
    $componentId = $_instance->getRenderedChildComponentId('F2g9fQk');
    $componentTag = $_instance->getRenderedChildComponentTagName('F2g9fQk');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('F2g9fQk');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.']);
    $html = $response->html();
    $_instance->logRenderedChild('F2g9fQk', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.'])->html();
} elseif ($_instance->childHasBeenRendered('9KWLsyD')) {
    $componentId = $_instance->getRenderedChildComponentId('9KWLsyD');
    $componentTag = $_instance->getRenderedChildComponentTagName('9KWLsyD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('9KWLsyD');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.']);
    $html = $response->html();
    $_instance->logRenderedChild('9KWLsyD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.'])->html();
} elseif ($_instance->childHasBeenRendered('147vcjD')) {
    $componentId = $_instance->getRenderedChildComponentId('147vcjD');
    $componentTag = $_instance->getRenderedChildComponentTagName('147vcjD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('147vcjD');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.']);
    $html = $response->html();
    $_instance->logRenderedChild('147vcjD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                </div>

            </div>

            <div class="flex justify-center">
                <a href="<?php echo e(route('register')); ?>" class="bg-yellow-500 hover:bg-yellow-400 text-white px-6 py-1 shadow-xl hover:shadow-none transition-shadow rounded-lg">Start Learning Today</a>
            </div>
        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/pages/aepp.blade.php ENDPATH**/ ?>