<?php $__env->startSection('content'); ?>

<div class="min-h-svh">

    <section>

        <div class="md:mt-8 p-6 space-y-6">
            <h2 class="text-2xl md:text-3xl font-semibold text-ezra-green">About this Program</h2>

            <p class="">The Graduate Agribusiness Extension Program (GAEP) is designed to empower individuals at various stages of their agribusiness careers. The program equips recent graduates with the knowledge and skills needed to excel in the field, while also addressing the needs of existing Extension Agents and retirees seeking to bridge knowledge gaps and enhance their expertise.</p>

            <div class="flex flex-wrap md:flex-nowrap justify-around gap-4">
                <img src="<?php echo e(asset('images/farmer-graduate.jpg')); ?>" alt="" class="w-full md:w-1/2 md:h-72 object-cover object-center">

                <div class="w-full">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure'])->html();
} elseif ($_instance->childHasBeenRendered('2tlLhBe')) {
    $componentId = $_instance->getRenderedChildComponentId('2tlLhBe');
    $componentTag = $_instance->getRenderedChildComponentTagName('2tlLhBe');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('2tlLhBe');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program Structure', 'body' => 'Some description about the program structure']);
    $html = $response->html();
    $_instance->logRenderedChild('2tlLhBe', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.'])->html();
} elseif ($_instance->childHasBeenRendered('f4zjdPi')) {
    $componentId = $_instance->getRenderedChildComponentId('f4zjdPi');
    $componentTag = $_instance->getRenderedChildComponentTagName('f4zjdPi');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('f4zjdPi');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Program duration', 'body' => '3 weeks.']);
    $html = $response->html();
    $_instance->logRenderedChild('f4zjdPi', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.'])->html();
} elseif ($_instance->childHasBeenRendered('QRgT8M6')) {
    $componentId = $_instance->getRenderedChildComponentId('QRgT8M6');
    $componentTag = $_instance->getRenderedChildComponentTagName('QRgT8M6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QRgT8M6');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Who can participate?', 'body' => 'This elearning course is open to agribusiness professionals.']);
    $html = $response->html();
    $_instance->logRenderedChild('QRgT8M6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.'])->html();
} elseif ($_instance->childHasBeenRendered('dGWK3RX')) {
    $componentId = $_instance->getRenderedChildComponentId('dGWK3RX');
    $componentTag = $_instance->getRenderedChildComponentTagName('dGWK3RX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('dGWK3RX');
} else {
    $response = \Livewire\Livewire::mount('accordion', ['title' => 'Certification', 'body' => 'You will get digital badges as you progress through the modules that make up the program and upon passing a final exam after completing the program and achieving a grade of at least 60%, you will be offered a certification.']);
    $html = $response->html();
    $_instance->logRenderedChild('dGWK3RX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


                </div>

            </div>

            <div class="flex justify-center">
                <a href="<?php echo e(route('register')); ?>" class="bg-yellow-500 hover:bg-yellow-400 text-white px-6 py-1 shadow-xl hover:shadow-none transition-shadow rounded-lg">Start Learning Today</a>
            </div>
        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/pages/gaep.blade.php ENDPATH**/ ?>