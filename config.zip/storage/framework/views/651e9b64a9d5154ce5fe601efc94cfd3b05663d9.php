<?php $__env->startSection('content'); ?>

<div class="min-h-svh px-6 mt-12">
        <h4 class="text-2xl md:text-3xl font-bold text-ezra-green">Course Catalogue</h4>

        <div class="grid md:grid-cols-4 my-12 gap-y-8 gap-x-4">

            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="shadow-sm hover:shadow-lg">
                <a href="<?php echo e(route('course.detail', ['course' => $course['shortname']])); ?>">
                    <img src="<?php echo e($course['courseimage']); ?>" class="h-48 w-full object-cover object-center" alt="">
                    <h4 class="font-bold text-md py-3 px-4"><?php echo e($course['fullname']); ?></h4>
                    
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/pages/course-catalogue.blade.php ENDPATH**/ ?>