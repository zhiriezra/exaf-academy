<?php $__env->startSection('content'); ?>

<div class="min-h-svh">

    <section>

        <div class="relative mx-auto">
            <img class="h-80 w-full object-cover object-top" src="<?php echo e($courseDetail['courseimage']); ?>" alt="Random image">
            <div class="absolute inset-0 bg-gray-700 opacity-60"></div>
            <div class="absolute inset-0 flex items-center justify-center">
                <h4 class="text-white text-3xl font-bold"><?php echo e($courseDetail['fullname']); ?></h4>

            </div>
        </div>

        <div class="p-6">
            <?php echo $courseDetail['summary']; ?>


                

            <div class="mt-4 flex justify-center">
                <a href="<?php echo e(route('register')); ?>" class="bg-yellow-500 hover:bg-yellow-400 text-white px-6 py-1 shadow-xl hover:shadow-none transition-shadow rounded-lg">Enroll Now</a>
            </div>
        </div>
    </section>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.components.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mamman Paul\Desktop\laravel\exaf-front\resources\views/pages/course.blade.php ENDPATH**/ ?>