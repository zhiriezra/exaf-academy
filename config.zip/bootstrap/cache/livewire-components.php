<?php return array (
  'accordion' => 'App\\Http\\Livewire\\Accordion',
  'courses.course-category' => 'App\\Http\\Livewire\\Courses\\CourseCategory',
  'testimonial' => 'App\\Http\\Livewire\\Testimonial',
);